# FTU physical time + EDACM-only v2

Exploratory signal diagnostic; no neural model training. Offset zero is an assumption, not verified synchronization.

Validated 3520 windows from 440 records. Offset sensitivity uses 3520 common windows.

FFT uses window-local EDACM; STFT uses full-record EDACM (target selection context differs). Top-three peaks within 5 bpm are an oracle diagnostic, not a deployable estimator. Circular label shifting is a weak negative control when HR changes little.

```csv
scope,group,method,n,mae,top3_hit,shifted_top3_hit
split,test,train_mean,704,4.3314618785847605,0.4815340909090909,0.47017045454545453
split,test,train_median,704,5.985139604048294,0.4815340909090909,0.47017045454545453
split,test,fft,704,20.676230135830966,0.4815340909090909,0.47017045454545453
split,test,stft,704,21.55313776189631,0.4815340909090909,0.47017045454545453
split,train,train_mean,2112,9.514286973040733,0.39820075757575757,0.37073863636363635
split,train,train_median,2112,9.442486757220642,0.39820075757575757,0.37073863636363635
split,train,fft,2112,23.11267496744792,0.39820075757575757,0.37073863636363635
split,train,stft,2112,23.802505030776516,0.39820075757575757,0.37073863636363635
split,val,train_mean,704,4.595897107084918,0.4034090909090909,0.38636363636363635
split,val,train_median,704,5.812169855291193,0.4034090909090909,0.38636363636363635
split,val,fft,704,23.66742664683949,0.4034090909090909,0.38636363636363635
split,val,stft,704,25.38322476473722,0.4034090909090909,0.38636363636363635
```

See per-subject CSV, alignment CSV and validation.json. Legacy exports are unchanged.
